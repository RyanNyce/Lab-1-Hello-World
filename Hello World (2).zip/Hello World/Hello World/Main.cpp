// Lab 1 - Hello World
// CSCN 111-005

/*
ALGORITHIM
We're going to print text to the screen
*/

// Pre-processor Directives 
#include <iostream>

using namespace std;

int main()
{
	// Print Hello World
	cout << "Let's Go Flames" << endl;

	system("pause");
	return 0;
}